# FlotaPro — Gestión de flota vehicular

## Funcionalidades del MVP
- Crear, editar, buscar, filtrar y eliminar vehículos.
- Controlar patente, año, kilometraje, próxima mantención y estado operativo.
- Mostrar alertas si la mantención vence o quedan 1.000 km o menos.
- Registrar historial de mantenimiento con fecha, tipo, kilometraje y observaciones.
- Validar patentes duplicadas y kilometraje coherente.
- Interfaz adaptable a escritorio y móvil.

## Publicar en Azure mediante IIS
1. Descomprime el ZIP en tu PC.
2. Copia `index.html`, `styles.css` y `app.js` a `C:\inetpub\wwwroot` dentro de la máquina virtual (RDP).
3. Desde tu PC abre `http://IP-PUBLICA-DE-TU-VM`.
4. Si no aparece la página, comprueba que IIS esté iniciado y que la regla de entrada TCP 80 esté permitida en Azure.

## Arquitectura realmente implementada
Navegador → petición HTTP → IIS en Windows Server de Azure → HTML/CSS/JavaScript → navegador. `app.js` implementa las validaciones, CRUD y alertas. `localStorage` guarda los datos en el navegador.

## Limitación
Esta versión es un MVP de demostración sin API ni base de datos central. Los datos solo quedan disponibles en el navegador donde se ingresaron; no se sincronizan entre distintos equipos. Para una versión multiusuario se debe incorporar backend/API y una base de datos, por ejemplo Azure App Service y Azure SQL, y documentar los recursos realmente utilizados.

Incluye vehículos ficticios de ejemplo. No ingresar información sensible.
